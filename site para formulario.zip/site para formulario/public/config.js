// Credenciais do painel (NAO COMMITAR — esta no .gitignore).
// Copie este arquivo junto com a pasta para usar em outro PC.
window.CONFIG = {
  SUPABASE_URL: "https://bjqarrswkxkgfdbxjuuj.supabase.co",
  SUPABASE_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJqcWFycnN3a3hrZ2ZkYnhqdXVqIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc2ODY5Nzg5NCwiZXhwIjoyMDg0MjczODk0fQ.j9HHd67MzeysOfN2XaqA8RacvvY69GQvMmQ4NTCI9PA", // service_role (admin, ignora RLS)
  OPENAI_API_KEY: "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",
  EMBEDDING_MODEL: "text-embedding-3-small"
};
